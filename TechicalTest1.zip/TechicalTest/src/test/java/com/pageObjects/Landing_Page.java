package com.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Landing_Page 
{
	 WebDriver driver;
	 public Landing_Page(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText="Form Authentication")
	WebElement lnkFormAuth;
	
	@FindBy(linkText="Infinite Scroll")
	WebElement lnkinfiniteScroll;
	
	@FindBy(linkText="Key Presses")
	WebElement lnkKeyPresses;
	
	@FindBy(xpath="//*[@id=\"content\"]/div/h3")
	WebElement txt_display2;
	
	@FindBy(id="result")
	WebElement txt_display3;
	
	
	public void clickFormAuth() 
	{
		lnkFormAuth.click();
	}
	public void clickInfiniteScroll() 
	{
		lnkinfiniteScroll.click();
	}
	public void clickKeyPresses() 
	{
		lnkKeyPresses.click();
	}
	public String captureText2()
	 {
		 return txt_display2.getText(); 
	 }

	public String captureText3()
	 {
		 return txt_display3.getText(); 
	 }
}
